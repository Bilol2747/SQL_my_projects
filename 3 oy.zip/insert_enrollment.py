import sqlite3
import random

connection = sqlite3.connect("test.db")
cursor = connection.cursor()

enrollments = []

# 1. MB dan students jadvalidagi studentlar id lari olinsin va ro'yxat ko'rinishiga keltirilsin (208 ta student bor)
cursor.execute("""
SELECT id FROM students;
""")

# fetchone()
# fetchmany(5)
# fetchall()
students_ids = [student_id[0] for student_id in cursor.fetchall()]
print(students_ids)
# 2. MB dan courses jadvalidagi courselar id lari olinsin va ro'yxat ko'rinishiga keltirilsin (11 ta course bor)
cursor.execute("""
SELECT id FROM courses;
""")
courses_id = [course_id[0] for course_id in cursor.fetchall()]
print(courses_id)

# 3. Sikl for har bir student id si ustidan yurib chiqamiz

for student_id in students_ids:
    # student 1 tadan 5 tagacha kurs tanlashini
    count_courses = random.randint(1, 5)

    # 4. Ro'yxat shakllantiriladi [student_id, course_idlar[ro'yxatdan] random id] va asosiy ro'yxatga qo'shiladi
    chosen_courses = random.sample(courses_id, count_courses)  # [3, 5, 9]
    for course_id in chosen_courses:
        enrollments.append((student_id, course_id))

# 5. Ushbu ro'yxat executemany orqali enrollments jadvaliga yoziladi

cursor.executemany("""
INSERT INTO enrollment(student_id, course_id) VALUES (?, ?);
""", enrollments)


# 6. Lekin MB dagi jadvallar arxitekturasi jihatidan biz many-to-many realizatsiya qilganmiz
# ya'ni har bir student 1 ta course emas balki bir nechta course o'qiy olish imkoniyatiga ega
# Lekin ma'lumot qo'shish jarayonida enrollments jadvalida 1 ta student uchun 1 ta course ko'rsatilmoqda !!!
# Bu yerda har bir student 1 tadan 5 tagacha course ko'rsatmoqchiman nima qilsam bo'ladi ???
# Random kutubxonasidan foydalanib har bir sikl qadamida yana bitta random son 1 dan 5 gacha olib
# har bir studentni olingan son bo'yicha shuncha marotaba random kurslarga yozsam, random
# kutubxonasa 2 marta 1, 1 yoki yana 1,1 berib qo'yishini oldini olishga to'g'ri keladi.
# Nima qilsak bo'ladi ?

connection.commit()
connection.close()

print(f"{len(enrollments)} ta enrollment yozildi !")


