import sqlite3

from data import get_students_data

connection = sqlite3.connect("test.db")
cursor = connection.cursor()

students = get_students_data()

cursor.executemany("""
    INSERT INTO students (full_name, age) VALUES (?, ?);
""", students)


# cursor.executemany("""
#     INSERT INTO courses(title, duration, lessons_count, price) VALUES (?,?,?,?);
# """, [
#     ("Python Backend Development", 8, 8*8, 8*1500000),
#     ("Frontend Web Development", 7, 7*8, 7*1500000),
#     ("Data Science (Python, ML, AI)", 8, 8*8, 8*1500000),
#     ("Mobile Development (Flutter)", 9, 9*8, 9*1500000),
#     ("UI/UX Design", 6, 6*8, 6*1500000),
#     ("System administration", 4, 4*8, 4*1500000),
#     ("Data Analytics", 4, 4*8, 4*1500000),
#     ("Social Media Marketing (SMM)", 6, 6*8, 6*1500000),
#     ("Office Pack (Excel, Word, Power Point)", 2, 2*8, 2*1500000),
#     ("Children Programming", 1, 1*8, 1*1500000),
#     ("Mobilography", 1, 1*8, 1*1500000)
# ])

courses = [
    ("Python Backend Development", 8, 8*8, 8*1500000),
    ("Frontend Web Development", 7, 7*8, 7*1500000),
    ("Data Science (Python, ML, AI)", 8, 8*8, 8*1500000),
    ("Mobile Development (Flutter)", 9, 9*8, 9*1500000),
    ("UI/UX Design", 6, 6*8, 6*1500000),
    ("System administration", 4, 4*8, 4*1500000),
    ("Data Analytics", 4, 4*8, 4*1500000),
    ("Social Media Marketing (SMM)", 6, 6*8, 6*1500000),
    ("Office Pack (Excel, Word, Power Point)", 2, 2*8, 2*1500000),
    ("Children Programming", 1, 1*8, 1*1500000),
    ("Mobilography", 1, 1*8, 1*1500000)
]


for course in courses:
    cursor.execute("""
        INSERT INTO courses(title, duration, lessons_count, price) VALUES (?,?,?,?);
    """,
                   (course[0], course[1], course[2], course[3]))

    connection.commit()



connection.commit()
connection.close()