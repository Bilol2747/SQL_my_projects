import requests


def get_students_data():
    response = requests.get("https://dummyjson.com/users?limit=208")
    data = response.json()
    users_data = data["users"]

    users = []

    for user in users_data:
        first_name = user["firstName"]
        last_name = user["lastName"]
        full_name = f"{first_name} {last_name}"
        age = user["age"]

        users.append([full_name, age])

    return users
