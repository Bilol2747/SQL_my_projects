import sqlite3

# connect() --- ulanadi agar MB mavjud bo'lsa,
# agar mavjud bo'lmasachi ? Yangi ko'rsatilgan nom MB ni yaratadi
connection = sqlite3.connect("test.db")
# cursor() --- MB ga ulanishning menjeri, ushbu menejer orqali siz MB ga so'rovlarni SQL tilida jo'nata olasiz
cursor = connection.cursor()
# so'rov jo'natish jarayoni
cursor.execute("""
    CREATE TABLE IF NOT EXISTS students(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name VARCHAR(100),
        age INTEGER
    );
""")

cursor.execute("""
    CREATE TABLE IF NOT EXISTS courses(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT UNIQUE,
        duration INTEGER,
        lessons_count INTEGER,
        price INTEGER
    );
""")

cursor.execute("""
    CREATE TABLE IF NOT EXISTS enrollment(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        enrolled_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        student_id INTEGER,
        course_id INTEGER,
        FOREIGN KEY (student_id) REFERENCES students(id),
        FOREIGN KEY (course_id) REFERENCES courses(id)
    );
""")

connection.commit()
connection.close()